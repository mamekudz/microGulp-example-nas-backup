// ===========================================
// i18x-hyphen.mjs - TeX-style hyphenation (µLib / i18xe-compatible)
// © 2026 Meinolf Amekudzi
// ===========================================

import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

const HYPHEN_CHAR = '\xAD'; // U+00AD soft hyphen
const hyphenData = {};
const hyphenCache = {};

/** Directory holding hyphen rule files: env override or `<cwd>/i18x/prod`. */
function _HyphenDir() {
	return process.env.MICROGULP_I18X_HYPHEN_DIR || join(process.cwd(), 'i18x', 'prod');
}

/**
 * Loads hyphen rules for a localization id from `<dir>/<lid>.hyphen.json`.
 * Missing or broken files yield a no-op catalog (`{ exist: false }`).
 * @param {string} _lid
 * @returns {object}
 */
export function LoadHyphenData(_lid) {
	if (hyphenData[_lid]) return hyphenData[_lid];
	let data = { exist: false };
	try {
		let filePath = join(_HyphenDir(), _lid + '.hyphen.json');
		if (existsSync(filePath)) data = JSON.parse(readFileSync(filePath, 'utf8'));
	} catch {
		// Malformed hyphen data must not break the build - fall back to no-op.
	}
	if (!data || typeof data !== 'object') data = { exist: false };
	hyphenData[_lid] = data;
	hyphenCache[_lid] = {};
	return data;
}

/**
 * Hyphenates a single word; returns the original when no rules exist.
 * @param {string} _word
 * @param {string} _lid
 * @returns {string}
 */
export function WordHyphenation(_word, _lid) {
	let word = String(_word);
	let data = LoadHyphenData(_lid);
	if (!data.exist) return word;
	if (!hyphenCache[_lid]) hyphenCache[_lid] = {};
	if (hyphenCache[_lid][word]) return hyphenCache[_lid][word];

	let lower = word.toLowerCase();
	let ret = word;

	if (!data.exceptions?.[lower]) {
		let sylbs = data.sylbs;
		let minSylbs = data.minSylbs;
		let maxSylbs = data.maxSylbs;
		let l = word.length + 1;
		let myword = '.' + lower;
		let vals = new Array(l + 1).fill(0);
		for (let i = 0; i < l; i++) {
			let sylb = '';
			for (let j = 0; (i + j) < l; j++) {
				sylb += myword.charAt(i + j);
				if (j >= minSylbs && j <= maxSylbs) {
					if (Object.prototype.hasOwnProperty.call(sylbs, sylb)) {
						let sylbVals = sylbs[sylb];
						let sl = sylb.length;
						for (let k = -1; k <= sl; k++) vals[i + k] = Math.max(sylbVals[k + 1], vals[i + k]);
					}
				} else if (j > maxSylbs) break;
			}
		}
		ret = '';
		let k = l - 3;
		let m = 2;
		l--;
		for (let i = 0; i < l; i++) {
			if ((vals[i] % 2) === 1 && i > m && i < k) ret += HYPHEN_CHAR;
			ret += word.charAt(i);
		}
	} else {
		let w = data.exceptions[lower];
		let j = 0;
		for (let i = 0; i < w.length; i++) {
			if (w.charAt(i) === HYPHEN_CHAR) {
				ret += word.charAt(j++);
			} else {
				ret += w.charAt(i);
			}
		}
	}

	hyphenCache[_lid][word] = ret;
	return ret;
}

/**
 * Hyphenates every word in a text; preserves HTML/XML tags.
 * @param {string} _text
 * @param {string} _lid
 * @returns {string}
 */
export function Hyphenation(_text, _lid) {
	let txts = String(_text);
	let ret = [];

	if (txts.indexOf('<') >= 0 && txts.indexOf('>') >= 0) {
		let tags = {};
		let matches = txts.match(/(<[^>]+>)/g);
		if (matches != null) {
			for (let i = 0; i < matches.length; i++) {
				tags[matches[i]] = '\x7F' + i + '\x7F';
				txts = txts.replace(matches[i], tags[matches[i]]);
			}
		}
		let words = txts.split(' ');
		for (let i = 0; i < words.length; i++) {
			let t = words[i].trim();
			ret.push(t ? WordHyphenation(t, _lid) : t);
		}
		txts = ret.join(' ');
		if (matches != null) {
			for (let i = 0; i < matches.length; i++) txts = txts.replace(tags[matches[i]], matches[i]);
		}
		return txts;
	}

	let words = txts.split(' ');
	for (let i = 0; i < words.length; i++) {
		let t = words[i].trim();
		ret.push(t ? WordHyphenation(t, _lid) : t);
	}
	return ret.join(' ');
}

/** @param {string} _target @param {string} _name @param {Function} _value */
function _DefinePrototype(_target, _name, _value) {
	if (typeof _target[_name] !== 'function') {
		Object.defineProperty(_target, _name, { value: _value, writable: true, configurable: true });
	}
}

/**
 * Installs µLib- and i18xe-compatible String hyphenation prototypes.
 * @param {function(): string} [_resolveLid] defaults to empty string when omitted
 */
export function InstallHyphenPrototypes(_resolveLid) {
	function _ResolveLid(_lid) {
		if (_lid) return _lid;
		try {
			return _resolveLid?.() ?? '';
		} catch {
			return '';
		}
	}
	let wordFn = function (_lid = '') { return WordHyphenation(String(this), _ResolveLid(_lid)); };
	let textFn = function (_lid = '') { return Hyphenation(String(this), _ResolveLid(_lid)); };
	_DefinePrototype(String.prototype, 'WordHyphenation', wordFn);
	_DefinePrototype(String.prototype, 'Hyphenation', textFn);
	_DefinePrototype(String.prototype, 'wordHyphenation', wordFn);
	_DefinePrototype(String.prototype, 'hyphenation', textFn);
}

export default { HYPHEN_CHAR, LoadHyphenData, WordHyphenation, Hyphenation, InstallHyphenPrototypes };
