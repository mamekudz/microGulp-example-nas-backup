// ===========================================
// gulp-mu-gulp-api - i18x console output for gulp tasks
// © 2026 Meinolf Amekudzi
// (published under MIT license)
// ===========================================

/**
 * Localized console output for gulp tasks, following the i18xe notation:
 * source strings are American English and carry a context tag
 * (`<context="task log"/>` …); translations live in the *consumer project's*
 * own `i18x/gulp/<lid>.json` files and `<name/>` placeholders are filled at
 * render time. Any project using µGulp drops an `i18x/gulp` directory next to
 * its gulpfile and its build output is localized - no coupling to µGulp
 * internals, works from the plain `gulp` CLI as well.
 *
 * The active language resolves from `MICROGULP_LANG` (the µGulp engine
 * forwards the dashboard language here), then the host OS locale, then the
 * en-US source. Regional/script variants fall back through a compact map
 * (`de-AT` → `de-DE`, `zh-TW` → `zh-CN`, `en-GB` → `en-US`, …) onto whichever
 * languages the project actually ships.
 *
 * @example
 * import { Log, Warn } from 'gulp-mu-gulp-api';
 * export async function BUILD() {
 *     Log('Compiling styles\u2026<context="task log"/>');
 *     Log('Chunk <n/>/<total/> written<context="task log"/>', { n: 3, total: 5 });
 * }
 *
 * @module gulp-mu-gulp-api/i18x
 */

import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { Trans as EngineTrans, FormatValue as EngineFormatValue, RegisterFormat } from './i18x-engine.mjs';
import { InstallHyphenPrototypes as _InstallHyphenPrototypes } from './i18x-hyphen.mjs';

const DEFAULT_LID = 'en-US';

// Compact locale fallback tables (subset of the µLib i18x LIDS_MAPS /
// LIDS_MAIN_CULTURES). The resolver also falls back on the bare language
// prefix, so only the non-obvious chains need listing.
const LIDS_MAPS = {
	'zh-CHS': ['zh-CN'], 'zh-CHT': ['zh-CHS', 'zh-CN'], 'zh-HK': ['zh-CHS', 'zh-CN'],
	'zh-Hans': ['zh-CHS', 'zh-CN'], 'zh-Hant': ['zh-CHT', 'zh-CHS', 'zh-CN'],
	'zh-MO': ['zh-CHS', 'zh-CN'], 'zh-SG': ['zh-CHS', 'zh-CN'], 'zh-TW': ['zh-CHT', 'zh-CHS', 'zh-CN'],
	'de-CH': ['de-DE'], 'de-AT': ['de-DE'], 'de-LU': ['de-DE'], 'de-LI': ['de-DE'],
	'en-GB': ['en-US'], 'en-AU': ['en-GB', 'en-US'], 'en-CA': ['en-GB', 'en-US'],
};
const LIDS_MAIN_CULTURES = {
	zh: 'CN', de: 'DE', en: 'GB', fr: 'FR', es: 'ES', it: 'IT', pt: 'PT',
	nl: 'NL', ru: 'RU', ja: 'JP', ko: 'KR',
};

let dictionaryCache = new Map();
let formatDefinitionCache = new Map();
let formatRegistryCache = new Map();
let availableLids = null;
let activeLid = null;
const timeZoneFormatters = {};

/** @returns {string} IANA timezone from MICROGULP_TZ, then ECMAScript Intl */
export function GetTimeZone() {
	if (process.env.MICROGULP_TZ) return process.env.MICROGULP_TZ;
	try {
		return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
	} catch {
		return 'UTC';
	}
}

/** Wall-clock Date in an IANA timezone (µLib-compatible). */
export function DateInTimeZone(_date, _timeZone) {
	let tz = _timeZone || GetTimeZone();
	try {
		let formatter = timeZoneFormatters[tz];
		if (formatter === undefined) {
			formatter = new Intl.DateTimeFormat('en-US', {
				timeZone: tz, hour12: false,
				year: 'numeric', month: '2-digit', day: '2-digit',
				hour: '2-digit', minute: '2-digit', second: '2-digit',
			});
			timeZoneFormatters[tz] = formatter;
		}
		let values = {};
		for (let part of formatter.formatToParts(_date)) values[part.type] = part.value;
		return new Date(
			parseInt(values.year, 10), parseInt(values.month, 10) - 1, parseInt(values.day, 10),
			parseInt(values.hour, 10) % 24, parseInt(values.minute, 10), parseInt(values.second, 10),
			_date.getMilliseconds(),
		);
	} catch {
		return _date;
	}
}

/**
 * Offset in minutes (UTC minus wall-clock, same sign as Date.getTimezoneOffset).
 * @param {Date|number} _date
 * @param {string} [_timeZone]
 * @returns {number}
 */
export function TimeZoneOffset(_date, _timeZone) {
	let date = _date instanceof Date ? _date : new Date(Number(_date) || 0);
	let shifted = DateInTimeZone(date, _timeZone);
	let wallAsUTC = Date.UTC(
		shifted.getFullYear(), shifted.getMonth(), shifted.getDate(),
		shifted.getHours(), shifted.getMinutes(), shifted.getSeconds(), shifted.getMilliseconds(),
	);
	return Math.round((date.getTime() - wallAsUTC) / 60000);
}

/** Normalizes casing: language lower, 2-letter region upper, 4-letter script Title. */
function _NormalizeLid(_lid) {
	if (!_lid) return '';
	let parts = String(_lid).replace(/_/g, '-').trim().split('-').filter(Boolean);
	if (parts.length === 0) return '';
	return parts.map((_part, _index) => {
		if (_index === 0) return _part.toLowerCase();
		if (_part.length === 2) return _part.toUpperCase();
		if (_part.length === 4) return _part.charAt(0).toUpperCase() + _part.slice(1).toLowerCase();
		return _part;
	}).join('-');
}

/**
 * Picks the closest shipped language for a wanted locale: exact
 * (case-insensitive) → LIDS_MAPS chain → main culture → language prefix →
 * en-US default → first available.
 */
function _BestAvailableLid(_wantedLid, _available) {
	if (_available.length === 0) return DEFAULT_LID;
	let wanted = _NormalizeLid(_wantedLid);
	if (!wanted) return _available.includes(DEFAULT_LID) ? DEFAULT_LID : _available[0];
	if (_available.includes(wanted)) return wanted;
	let caseInsensitive = _available.find((_lid) => _lid.toLowerCase() === wanted.toLowerCase());
	if (caseInsensitive) return caseInsensitive;
	if (Object.prototype.hasOwnProperty.call(LIDS_MAPS, wanted)) {
		for (let candidate of LIDS_MAPS[wanted]) if (_available.includes(candidate)) return candidate;
	}
	let language = wanted.split('-')[0];
	if (Object.prototype.hasOwnProperty.call(LIDS_MAIN_CULTURES, language)) {
		let mainCulture = language + '-' + LIDS_MAIN_CULTURES[language];
		if (_available.includes(mainCulture)) return mainCulture;
	}
	let byPrefix = _available.find((_lid) => _lid.split('-')[0].toLowerCase() === language);
	if (byPrefix) return byPrefix;
	return _available.includes(DEFAULT_LID) ? DEFAULT_LID : _available[0];
}

/** Directory holding the project dictionaries: env override or `<cwd>/i18x/gulp`. */
function _DictionaryDir() {
	return process.env.MICROGULP_I18X_DIR || join(process.cwd(), 'i18x', 'gulp');
}

/** Languages shipped by the project (en-US source is always available). */
function _AvailableLids() {
	if (availableLids) return availableLids;
	let lids = [DEFAULT_LID];
	try {
		for (let entry of readdirSync(_DictionaryDir())) {
			if (!entry.toLowerCase().endsWith('.json')) continue;
			let lid = entry.slice(0, -5);
			if (!lids.includes(lid)) lids.push(lid);
		}
	} catch {
		// No dictionary directory - only the en-US source is available.
	}
	availableLids = lids;
	return availableLids;
}

/** Resolves the active language from MICROGULP_LANG, OS locale, then default. */
function _ResolveLid() {
	let wanted = process.env.MICROGULP_LANG;
	if (!wanted) {
		try {
			wanted = Intl.DateTimeFormat().resolvedOptions().locale;
		} catch {
			// Intl is always present in Node 22, but stay defensive.
		}
	}
	return _BestAvailableLid(wanted || process.env.LANG || DEFAULT_LID, _AvailableLids());
}

/** @returns {string} the active localization id (cached after first use) */
export function GetLid() {
	if (!activeLid) activeLid = _ResolveLid();
	return activeLid;
}

/**
 * Overrides the active language explicitly and clears caches so the next
 * translation reloads. Pass a falsy value to reset to automatic resolution.
 * @param {string} [_lid]
 */
export function SetLid(_lid) {
	activeLid = _lid ? _BestAvailableLid(_lid, _AvailableLids()) : null;
	dictionaryCache.clear();
	formatDefinitionCache.clear();
	formatRegistryCache.clear();
	availableLids = null;
}

/** Loads and caches `<dir>/<lid>.json`; a missing/broken file yields source text. */
function _LoadDictionary(_lid) {
	if (dictionaryCache.has(_lid)) return dictionaryCache.get(_lid);
	let dictionary = {};
	try {
		let filePath = join(_DictionaryDir(), _lid + '.json');
		if (existsSync(filePath)) dictionary = JSON.parse(readFileSync(filePath, 'utf8'));
	} catch {
		// A malformed dictionary must not break the build - fall back to source.
	}
	dictionaryCache.set(_lid, dictionary);
	return dictionary;
}

/** @param {Record<string, string>} _dictionary */
function _ExtractFormatDefinitions(_dictionary) {
	let formats = {};
	for (let [key, value] of Object.entries(_dictionary)) {
		if (!key.startsWith('<format name=')) continue;
		let match = key.match(/<format name="([^"]+)"/);
		if (match) formats[match[1]] = value;
	}
	return formats;
}

/** Localized i18xe format XML keyed by format id (from i18x/gulp dictionaries). */
function _LoadFormatDefinitions(_lid) {
	if (formatDefinitionCache.has(_lid)) return formatDefinitionCache.get(_lid);
	let formats = { ..._ExtractFormatDefinitions(_LoadDictionary(DEFAULT_LID)) };
	if (_lid !== DEFAULT_LID) {
		Object.assign(formats, _ExtractFormatDefinitions(_LoadDictionary(_lid)));
	}
	formatDefinitionCache.set(_lid, formats);
	return formats;
}

/** Builds (and caches) the name→parsed-definition format registry for a language. */
function _FormatRegistry(_lid) {
	if (formatRegistryCache.has(_lid)) return formatRegistryCache.get(_lid);
	let registry = Object.create(null);
	let definitions = _LoadFormatDefinitions(_lid);
	for (let xml of Object.values(definitions)) RegisterFormat(registry, xml, false);
	formatRegistryCache.set(_lid, registry);
	return registry;
}

/** Assembles the engine render context (language, timezone, format registry). */
function _RenderContext(_lid, _timeZone) {
	let lid = _lid ?? GetLid();
	return { lid, timeZone: _timeZone ?? GetTimeZone(), formats: _FormatRegistry(lid) };
}

/**
 * Formats a numeric/date value with a named i18xe format definition from the
 * project's i18x/gulp dictionaries (synced from i18xe prod). Delegates to the
 * eval-free i18x engine, so the full i18x notation (fill/padding, `if`
 * conditions, nested formats, expressions, enumerations, date parts) is honored.
 * Date/time formats interpret the value as milliseconds since the Unix epoch.
 * @param {number|string} _value
 * @param {string} _formatName e.g. 'int', 'floatFix2', 'byteSize', 'stdDateTime'
 * @param {string} [_lid]
 * @param {string} [_timeZone] IANA timezone id (defaults to GetTimeZone())
 * @returns {string}
 */
export function FormatValue(_value, _formatName, _lid, _timeZone) {
	let context = _RenderContext(_lid, _timeZone);
	if (!Object.prototype.hasOwnProperty.call(context.formats, _formatName)) return String(_value);
	return EngineFormatValue(_value, _formatName, context);
}

/**
 * Translates a source phrase (including its context tag) into the active
 * language and renders it through the i18x engine (placeholders, `format="…"`,
 * `if` conditions, …). Unknown phrases fall back to the en-US source text.
 * @param {string} _text source phrase, e.g. 'Build ready<context="task log"/>'
 * @param {object} [_values] placeholder values for `<name/>` tags
 * @param {string} [_timeZone] IANA timezone id (defaults to GetTimeZone())
 * @returns {string}
 */
export function Translate(_text, _values, _timeZone) {
	if (_text == null) return '';
	let source = String(_text);
	let lid = GetLid();
	let dictionary = lid === DEFAULT_LID ? null : _LoadDictionary(lid);
	let translated = (dictionary && Object.prototype.hasOwnProperty.call(dictionary, source)) ? dictionary[source] : source;
	// The context tag is part of the dictionary key only; strip it before rendering.
	translated = translated.replace(/<context=[^>]*>/g, '');
	return EngineTrans(translated, _values ?? {}, _RenderContext(lid, _timeZone));
}

/**
 * console.log through i18x. Prefer the `<context="task log"/>` tag.
 * @param {string} _text source phrase
 * @param {object} [_values]
 */
export function Log(_text, _values) {
	console.log(Translate(_text, _values));
}

/**
 * console.warn through i18x. Prefer the `<context="task warning"/>` tag.
 * @param {string} _text source phrase
 * @param {object} [_values]
 */
export function Warn(_text, _values) {
	console.warn(Translate(_text, _values));
}

/**
 * console.error through i18x. Prefer the `<context="task error"/>` tag.
 * Named LogError to avoid shadowing the global Error constructor.
 * @param {string} _text source phrase
 * @param {object} [_values]
 */
export function LogError(_text, _values) {
	console.error(Translate(_text, _values));
}

/**
 * µLib-compatible String-prototype API for gulpfiles that prefer the
 * `"text<context=\"…\"/>".i18xTrans({ … })` ergonomics over the Log/Warn
 * helpers. Installs `I18xTrans`/`i18xTrans` and `I18xRegister`/`i18xRegister`
 * - but never overwrites an implementation already provided by µLib (µLib
 * wins when both are loaded). Called automatically on import; also exported
 * for explicit control.
 */
export function InstallStringExtensions() {
	if (typeof String.prototype.I18xTrans !== 'function') {
		Object.defineProperty(String.prototype, 'I18xTrans', {
			value: function (_values, _timeZone) { return Translate(String(this), _values, _timeZone); },
			writable: true, configurable: true,
		});
	}
	if (typeof String.prototype.i18xTrans !== 'function') {
		Object.defineProperty(String.prototype, 'i18xTrans', {
			value: String.prototype.I18xTrans,
			writable: true, configurable: true,
		});
	}
	if (typeof String.prototype.I18xRegister !== 'function') {
		Object.defineProperty(String.prototype, 'I18xRegister', {
			value: function () { return String(this); },
			writable: true, configurable: true,
		});
	}
	if (typeof String.prototype.i18xRegister !== 'function') {
		Object.defineProperty(String.prototype, 'i18xRegister', {
			value: String.prototype.I18xRegister,
			writable: true, configurable: true,
		});
	}
	InstallFormatPrototypes();
	InstallHyphenPrototypes();
}

/**
 * Installs String hyphenation prototypes (µLib + i18xe aliases). Called from
 * InstallStringExtensions (auto-run on import); also exported for explicit control.
 */
export function InstallHyphenPrototypes() {
	_InstallHyphenPrototypes(GetLid);
}

// .NET ticks are 100-nanosecond intervals since 0001-01-01; this offset is the
// tick count at the Unix epoch (1970-01-01), so ms = (ticks - offset) / 10000.
const TICKS_EPOCH_OFFSET = 621355968000000000;
const TICKS_PER_MILLISECOND = 10000;

/** @param {string} _name @param {Function} _value install a prototype method only if absent (µLib wins) */
function _DefinePrototype(_target, _name, _value) {
	if (typeof _target[_name] !== 'function') {
		Object.defineProperty(_target, _name, { value: _value, writable: true, configurable: true });
	}
}

/**
 * µLib-compatible Number/Date/String `Format` prototypes for gulpfiles that
 * prefer `(1536).Format('byteSize')` or `new Date().Format('stdDateTime')`
 * over the FormatValue() helper. Date/time formats interpret their value as
 * milliseconds since the Unix epoch (µGulp convention), except FormatTicks
 * which takes .NET ticks. Never overwrites an implementation already provided
 * by µLib (µLib wins when both are loaded). Called from InstallStringExtensions
 * (auto-run on import); also exported for explicit control.
 */
export function InstallFormatPrototypes() {
	// Number.prototype.Format - number formats use the value directly, date
	// formats interpret it as milliseconds since the Unix epoch.
	_DefinePrototype(Number.prototype, 'Format', function (_format, _lid, _timeZone) {
		return FormatValue(this.valueOf(), _format, _lid, _timeZone);
	});
	// Number.prototype.FormatTimestamp - an explicit Unix millisecond timestamp.
	_DefinePrototype(Number.prototype, 'FormatTimestamp', function (_format, _lid, _timeZone) {
		return FormatValue(this.valueOf(), _format, _lid, _timeZone);
	});
	// Number.prototype.FormatTicks - a .NET tick count, converted to ms first.
	_DefinePrototype(Number.prototype, 'FormatTicks', function (_format, _lid, _timeZone) {
		let ms = (this.valueOf() - TICKS_EPOCH_OFFSET) / TICKS_PER_MILLISECOND;
		return FormatValue(ms, _format, _lid, _timeZone);
	});
	// i18xe-sync lowercase aliases.
	_DefinePrototype(Number.prototype, 'format', Number.prototype.Format);
	_DefinePrototype(Number.prototype, 'formatTimestamp', Number.prototype.FormatTimestamp);
	_DefinePrototype(Number.prototype, 'formatTicks', Number.prototype.FormatTicks);
	// Date.prototype.Format - formats via the date's millisecond timestamp.
	_DefinePrototype(Date.prototype, 'Format', function (_format, _lid, _timeZone) {
		return FormatValue(this.getTime(), _format, _lid, _timeZone);
	});
	_DefinePrototype(Date.prototype, 'format', Date.prototype.Format);
	// String.prototype.Format - µLib parity: a string has no numeric format.
	_DefinePrototype(String.prototype, 'Format', function () {
		return this.valueOf();
	});
}

InstallStringExtensions();

export default {
	GetLid, SetLid, GetTimeZone, DateInTimeZone, TimeZoneOffset,
	Translate, FormatValue, Log, Warn, LogError,
	InstallStringExtensions, InstallFormatPrototypes, InstallHyphenPrototypes,
};
