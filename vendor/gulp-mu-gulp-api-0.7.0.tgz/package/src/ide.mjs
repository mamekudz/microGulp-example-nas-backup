// ===========================================
// ide.mjs - IDE-bridge task API
// © 2026 Meinolf Amekudzi
// ===========================================

/**
 * Portable Core plus native host commands. Without µGulp (plain gulp CLI)
 * every call returns `{ ok: false, code, message }` and never throws.
 *
 * @module gulp-mu-gulp-api/ide
 */

function IsMicroGulp() {
	return process.env.MICROGULP === '1' && typeof process.send === 'function';
}

const IDE_ERROR_CODES = Object.freeze({
	UnsupportedEdition: 'unsupported-edition',
	UnsupportedHost: 'unsupported-host',
	UnsupportedOperation: 'unsupported-operation',
	IncompatibleHost: 'incompatible-host',
	CommandNotAllowed: 'command-not-allowed',
	CommandFailed: 'command-failed',
	Timeout: 'timeout',
});

const CLI_FALLBACK = Object.freeze({
	ok: false,
	code: IDE_ERROR_CODES.UnsupportedHost,
	message: 'IDE commands need a µGulp host (VS Code, Cursor, or a JetBrains IDE).',
});

const IDE_BRIDGE_PROTOCOL = 3;
const IDE_CLIENT_TIMEOUT_MS = 15_000;

let requestCounter = 0;
let listenerAttached = false;
const pending = new Map();

function _AttachListener() {
	if (listenerAttached) return;
	listenerAttached = true;
	process.on('message', (_message) => {
		if (!_message || _message.type !== 'ide-response') return;
		let resolver = pending.get(_message.requestId);
		if (!resolver) return;
		resolver(_message.payload);
	});
	process.on('disconnect', () => {
		for (let resolver of [...pending.values()]) {
			resolver({ ok: false, code: IDE_ERROR_CODES.CommandFailed, message: 'The µGulp worker disconnected.' });
		}
	});
}

function _Request(_operation, _fields = {}) {
	if (!IsMicroGulp()) return Promise.resolve({ ...CLI_FALLBACK });
	_AttachListener();
	let requestId = `ide-${++requestCounter}-${Date.now()}`;
	return new Promise((_resolve) => {
		let settled = false;
		let Finish = (_payload) => {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			pending.delete(requestId);
			_resolve(_payload && typeof _payload === 'object'
				? _payload
				: { ok: false, code: IDE_ERROR_CODES.CommandFailed, message: 'Empty IDE response.' });
		};
		let timer = setTimeout(() => {
			Finish({
				ok: false,
				code: IDE_ERROR_CODES.Timeout,
				message: 'The IDE host did not answer the command in time.',
			});
		}, IDE_CLIENT_TIMEOUT_MS);
		timer.unref?.();
		pending.set(requestId, Finish);
		try {
			process.send({
				type: 'ide-request',
				requestId,
				protocol: IDE_BRIDGE_PROTOCOL,
				operation: _operation,
				vscodeCommand: typeof _fields.vscodeCommand === 'string' ? _fields.vscodeCommand : '',
				jetbrainsAction: typeof _fields.jetbrainsAction === 'string' ? _fields.jetbrainsAction : '',
				commandId: typeof _fields.commandId === 'string' ? _fields.commandId : '',
				args: Array.isArray(_fields.args) ? _fields.args : [],
			});
		} catch {
			Finish({
				ok: false,
				code: IDE_ERROR_CODES.CommandFailed,
				message: 'The IDE request could not be sent.',
			});
		}
	});
}

/**
 * Host capability snapshot (`protocol`, `hostFamily`, `edition`, `operations`).
 * @returns {Promise<{ ok: boolean, result?: object, code?: string, message?: string }>}
 */
export function Capabilities() {
	return _Request('core.capabilities');
}

/**
 * Portable execute: supply one id per host family. No implicit rewriting.
 * Later portable operations are new methods on `Ide` (this shape stays).
 * @param {object} _spec
 * @param {string} [_spec.vscode] VS Code / Cursor command id
 * @param {string} [_spec.jetbrains] IntelliJ action id
 * @param {unknown[]} [_spec.args]
 * @returns {Promise<{ ok: boolean, result?: unknown, code?: string, message?: string }>}
 */
export function Execute(_spec = {}) {
	return _Request('core.execute', {
		vscodeCommand: typeof _spec.vscode === 'string' ? _spec.vscode : '',
		jetbrainsAction: typeof _spec.jetbrains === 'string' ? _spec.jetbrains : '',
		commandId: typeof _spec.commandId === 'string' ? _spec.commandId : '',
		args: Array.isArray(_spec.args) ? _spec.args : [],
	});
}

/**
 * VS Code / Cursor `executeCommand`. Fails on a JetBrains or browser host.
 * @param {string} _commandId
 * @param {...unknown} _args
 */
export function ExecuteCommand(_commandId, ..._args) {
	return _Request('vscode.executeCommand', {
		commandId: typeof _commandId === 'string' ? _commandId : '',
		args: _args,
	});
}

/**
 * IntelliJ `ActionManager` action. Fails on VS Code / Cursor / browser.
 * @param {string} _actionId
 */
export function ExecuteAction(_actionId) {
	return _Request('jetbrains.executeAction', {
		commandId: typeof _actionId === 'string' ? _actionId : '',
		args: [],
	});
}

export const Vscode = {
	ExecuteCommand,
};

export const JetBrains = {
	ExecuteAction,
};

export const Ide = {
	Projects,
	Action,
	OpenProject,
	StartApplication,
	Capabilities,
	Execute,
	Vscode,
	JetBrains,
};

export { IDE_ERROR_CODES };

/** Execute a semantic action advertised by Ide.Capabilities(). */
export function Action(_id) { return _Request('core.action', { args: [_id] }); }
/** Open a known project in a configured installation, or focus its exact session. */
export function OpenProject(_request) { return _Request('project.execute', { args: [{ ..._request, action: 'open-focus-project' }] }); }
/** Start an explicitly configured local application (no shell command accepted). */
export function StartApplication(_applicationId) { return _Request('project.execute', { args: [{ action: 'start-application', applicationId: _applicationId }] }); }

/** Known projects, live sessions and configured application choices. */
export function Projects() { return _Request('project.execute', { args: [{ action: 'list-projects' }] }); }
