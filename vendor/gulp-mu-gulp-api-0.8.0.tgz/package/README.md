# gulp-mu-gulp-api

## 0.8.0 - task run context

`GetTaskRunContext()` returns why the current task invocation started, for example `{ reason: 'schedule', scheduleId: 'backup-daily' }`. Manual runs and ordinary Gulp CLI runs return `{ reason: 'manual' }`. The context is scoped to one task call and is cleared before a warm worker is reused. This additive API requires µGulp 1.2.0 or later; older hosts do not provide scheduled trigger details.

## 0.7.0 - forms and metadata

Requires µGulp™ 1.1.0 for the new dashboard features. `RequestForm` accepts optional `information: { title, message, values, items: [{ key, value }] }`, `cancelable: true`, and `rememberKey`. Explicit cancellation resolves to `null`; successful responses retain the field-value object. Always handle `null` before reading fields. Persistence is opt-in, scoped to task and form, and excludes passwords, `secret: true`, and `remember: false`. Keep execution approval and secrets out of remembered values. The CLI fallback prints information and supports `:cancel` interactively; it does not persist form values.

The exported `µI18xContext` object may contain a synchronous `GetValues()` method returning fresh placeholders. It must not perform backup or other write operations. `NotifyTasksChanged()` refreshes metadata after a task. Existing plain-object contexts and forms remain supported.

This source version is prepared for release; it does not imply npm publication.

<p align="center">
  <a href="https://microgulp.dev">
    <img src="https://microgulp.dev/assets/media/logo_readme.png" alt="µGulp logo" width="180">
  </a>
</p>

<p align="center">
  <a href="https://microgulp.dev/en/#%C2%B5gulp-ready">
    <img src="https://microgulp.dev/assets/media/microgulp-ready.png" alt="µGulp Ready" width="110">
  </a>
</p>

<p align="center"><strong>Rock your Gulp!</strong><br/>
µGulp™, the interactive near-zero-latency task orchestrator with rich visuals, webview controls, and audio feedback.</p>

Public task API of the **µGulp™** orchestrator - progress reporting, i18x console output and interactive dashboard inputs from within gulp tasks.

[![npm version](https://img.shields.io/npm/v/gulp-mu-gulp-api.svg)](https://www.npmjs.com/package/gulp-mu-gulp-api) · [µGulp™](https://microgulp.dev) · [Support](mailto:support@microgulp.dev)

[English](#english) · [Deutsch](#deutsch)

---

# English

**Rock your Gulp!** - µGulp™, the interactive near-zero-latency task orchestrator with rich visuals, webview controls, and audio feedback.

**gulp-mu-gulp-api** gives gulp tasks (and any npm package inside the task stream) access to the extended µGulp™ dashboard features: progress bars, validated text inputs, color and font pickers, single and multi selections, sliders and complete forms.

The module is deliberately **dependency-free** and knows nothing about µGulp™ internals: when the task runs under µGulp™, it talks directly to the engine over the worker process IPC channel. When the gulpfile runs through the classic gulp CLI, every function degrades gracefully - progress renders on the terminal, inputs are asked via readline (TTY) or answered with the declared defaults (CI/non-TTY). Tasks stay fully runnable without µGulp™.

## Installation

```bash
npm install gulp-mu-gulp-api
```

### 0.6.0

- **Added** `Ide.Projects()`, `Ide.Action(id)`, `Ide.OpenProject(request)` and `Ide.StartApplication(applicationId)` - known projects, semantic IDE actions, Open/Focus Project and explicitly configured applications. See [IDE and project API](#ide-and-project-api).
- **Added** `ScheduleTask(spec)`, `SetScheduleEnabled(id, enabled)`, `CancelSchedule(id)` and `RunScheduleNow(id)` - imperative counterpart of the `µSchedule` task metadata (session schedules; every run still goes through the normal task start).
- **Added** `GetProjectControls()` / `GetProjectControl(id, fallback?)` - values of the project control bar (`select` / `radio` / `checkbox`), frozen when the run starts. Outside µGulp: `MICROGULP_CONTROLS` (JSON) or `MICROGULP_CONTROL_<ID>`.
- Purely additive: all 0.5.0 exports and signatures are unchanged. The new functions need µGulp™ **1.0.0** or later; older hosts answer IDE calls with an error result, schedule calls are ignored, and project controls read as empty.

### 0.5.0

- **Added** `LogAccordion({ title?, items })` - collapsible sections in the run log (`summary` + `lines` / `body`, optional `open`). Dashboard renders native `<details>` with Expand/Collapse-all when multiple items exist. CLI fallback: titled bullet sections on stdout.
- Requires a matching µGulp dashboard that understands structured-log format `accordion` (shipped with current µGulp packages). Older hosts ignore unknown formats.

### Host note (µGulp 0.9.6+) - no API bump

- Long `select` / `radio` / `checkbox` option lists: `RequestForm` still sends the full payload (no API-side cap). Declarative `µParameters` are normalized by the **host** with a safety ceiling of **5000** options per field (was a silent 200). Override with `MICROGULP_MAX_SELECT_OPTIONS` (`0` / `unlimited` = no cap). Truncation sets host metadata and the dashboard warns instead of dropping entries silently. Selects with 24+ options get a typeahead filter in the dashboard. Details: Field types section below.
- No new exports or breaking changes in this package - upgrade the µGulp host/extension to pick up the behavior.

### 0.4.3

- **Updated** the Ready badge to the published `/en/ready/` page (110px, no fixed height) and documented the actual CLI fallback: `ShowModalMessage()` / `ShowConfirmMessage()` return `{ button: 'ok' }`; Gulp CLI does not apply `µParameters` defaults.
- **Added** filesystem path pickers: form types `file` and `folder` (`directory` alias), `RequestFileInput()` / `RequestFolderInput()`, and the same types on `µParameters`. The dashboard shows a path field plus Browse (native OS dialog in VS Code, Cursor and JetBrains IDEs). The value is the real path string, not a browser `fakepath`.
- **Added** `ReloadHostWindow()` - after a successful run, reload the VS Code/Cursor window (`Developer: Reload Window`); no-op in the gulp CLI, JetBrains and the browser demo.
- **Updated** `NotifyTasksChanged()` so the dashboard also re-evaluates `µAttention` / `µAttentionTooltip`, not only `µEnabled` and tooltips.

### 0.4.2

- **Updated** homepage, support and README images to the public site [microgulp.dev](https://microgulp.dev) and [support@microgulp.dev](mailto:support@microgulp.dev). The source repository is private.

### 0.4.1

- **Fixed** a placeholder with an unknown named format rendered as an empty string instead of its value - gulp lifecycle lines lost their duration (`Finished 'task' after`). The raw value is kept when the format is missing.
- **Fixed** `SetLid()` kept the dictionary of the previous language cached, so a language switch inside a running worker could still translate with stale texts.

### 0.4.0

- **Added** `GetParameters()` / `GetParameter(id, fallback)` - values for the inputs a task declared with `µParameters`. µGulp asks for them once before the task body runs and passes them in as `MICROGULP_PARAMS` (JSON) plus one flat `MICROGULP_PARAM_<ID>` per parameter.
- Works outside µGulp too: set the same environment variables by hand (`MICROGULP_PARAM_TARGET=staging npx gulp DEPLOY`) or pass a fallback to `GetParameter()`. Gulp CLI does not apply `µParameters` defaults automatically; flat environment values are strings.
- Related gulpfile metadata added by µGulp 0.7.0: `µParameters` (declarative inputs), `µKeyBinding` (dashboard shortcut), `µWatch` (file trigger). They are plain task properties - no API call needed.

### 0.3.13

- **Updated** `PlaySignal` / `PlaySound` docs and CLI fallbacks for the µGulp sound schema (`taskSuccess`, `taskFailed`, `requestAlert`, …). Legacy presets `success` / `error` / `attention` remain valid.

### 0.3.12

- **Added** `RegisterDashboardFont({ id, file, family?, usage? })` - registers a workspace font for µGulp dashboard **task icons** and/or **run-log** typography. `usage`: `'task-icons'` (default), `'log'`, or `'all'`. Call at gulpfile load time; the scan worker forwards the registry to the engine.
- **Added** `GetRegisteredDashboardFonts()` / `ClearRegisteredDashboardFonts()` - snapshot / test helpers.
- Pair with gulpfile metadata `µIcon` (glyph) and optional `µIconFont = '<id>'`, or declarative `export const µDashboardFonts = […]`. Config/setting `dashboardFonts` is an alternative when not using the API.
- Outside µGulp the helpers are no-ops (fonts are a dashboard/host concern).

### 0.3.11

- **Added** `ShowModalMessage({ variant?, title?, message?, buttons?, presentation? })` - blocking modal (info/warning/error) in the µGulp dashboard glass panel, or native VS Code/Cursor dialogs when `presentation` is `ide`/`auto` (host setting `microgulp.modalPresentation`).
- **Added** `ShowConfirmMessage({ title?, message?, variant?, style?, presentation? })` - Yes/No or OK/Cancel confirmation; resolves with `{ button: 'yes'|'no'|'ok'|'cancel'|… }`.
- Outside µGulp both helpers write a bracketed console line and return `{ button: 'ok' }`. That is not a CLI approval - require an explicit option or abort for consequential actions.

### 0.3.10

- **Fixed** `IsMicroGulp()` / `IsµGulp()` - returns `true` only when `MICROGULP=1` **and** `typeof process.send === 'function'`. Child processes that inherit `MICROGULP` without an IPC channel (nested gulp runs, test subprocesses) no longer crash on `process.send`.

### 0.3.8

- **Added** structured log elements rendered directly in the run log (JSON payloads, Content-Security-Policy safe, no plugin/iframe needed): `LogCallout()` (info/success/warning/error box), `LogKeyValue()` (metrics/summary list), `LogBadges()` (status chips), `LogCode()` (monospace code block) and `LogChart()` (inline-SVG bar chart).
- Each new helper degrades to a readable stdout fallback when running outside µGulp (bracketed callout, aligned key/value lines, bracketed badges, verbatim code, ASCII bar chart).

### 0.3.7

- **Added** engine date/time placeholders: `weekofyear`, `dayofyear`, `utcweekofyear`, `utcdayofyear`, `timezoneoffset`, `timezoneshort`, `timezoneplace`.
- **Added** `TimeZoneOffset()` - JavaScript-compatible offset in minutes (same sign as `Date.getTimezoneOffset()`).
- **Added** hyphenation API: `WordHyphenation()`, `Hyphenation()`, `LoadHyphenData()`, `InstallHyphenPrototypes()` with µLib (`WordHyphenation`/`Hyphenation`) and i18xe-sync (`wordHyphenation`/`hyphenation`) aliases; without `<lid>.hyphen.json` data the methods no-op.
- **Added** i18xe-sync lowercase format aliases: `Number.prototype.format()` / `.formatTimestamp()` / `.formatTicks()`, `Date.prototype.format()`.
- **Changed** `Translate(text, values?, timeZone?)` and `.i18xTrans(values?, timeZone?)` accept an optional IANA timezone override.

### 0.3.6

- **Added** full eval-free i18x engine (`i18x-engine.mjs`): `FormatValue()`/`Translate()` now honor the complete i18x notation - `if`/`ifnot`/`ifin` conditions, nested formats, `expression="…"`, enumerations, digit fill/padding, date/time parts and roman numerals.
- **Added** µLib-compatible `Number.prototype.Format()`, `Number.prototype.FormatTimestamp()`, `Number.prototype.FormatTicks()`, `Date.prototype.Format()` and `String.prototype.Format()` (installed automatically on import; see `InstallFormatPrototypes()`).
- **Changed** `FormatValue(value, format, lid?, timeZone?)` gained the optional `timeZone` argument; date/time formats interpret the value as Unix milliseconds.

### 0.3.5

- **Added** `PlaySound(sample, { loop? })` and `StopSound(sample)` - play named samples from the dashboard µAU sound atlas; `loop: true` repeats until `StopSound`.
- **Changed** npm README: clearer i18x section (`Log`/`Warn` vs `.i18xTrans()` / `.i18xRegister()`).

### 0.3.3

- **Changed** npm README: centered µGulp logo and µGulp ready badge (absolute raw URLs from the µGulp repo).

### 0.3.2

- **Added** `FormatValue()` - renders `<name format="…"/>` placeholders from `<format …>` XML definitions in the consumer project's `i18x/gulp/<lid>.json`.
- **Changed** built-in format IDs to CamelCase (`floatFix2`, `stdDate`, `progressDuration`, `byteSize`, …); lifecycle duration logs expect raw milliseconds with `format="progressDuration"`.

### 0.3.0

- **Added** integrated i18x console layer: `Log`, `Warn`, `LogError`, `Translate`, `GetLid`, `SetLid`, `GetTimeZone`, `DateInTimeZone`, `InstallStringExtensions` - translations live in the consumer project's `i18x/gulp/<lid>.json`; language follows `MICROGULP_LANG` (set by the µGulp dashboard) with locale fallback.
- **Added** µLib-compatible `String.prototype.i18xTrans()` / `.i18xRegister()` (installed automatically on import).
- **Removed** `µMeta()` / `MicroGulpMeta` - embed the context tag in the source phrase and use `.i18xRegister()` instead (see below).

## Usage

```javascript
import { ReportProgress, CreateProgress, PlaySignal, PlaySound, StopSound, Speak, RequestTextInput, RequestColorInput, RequestFontInput, RequestSelectInput, RequestMultiSelectInput, RequestForm, RegisterDashboardFont, IsMicroGulp, IsµGulp, InstallStringExtensions } from 'gulp-mu-gulp-api';

// Enables "phrase<context=\"…\"/>".i18xRegister()/.i18xTrans() on strings.
InstallStringExtensions();

export async function BUILD_THEME() {
    // single inputs
    let accent = await RequestColorInput({ label: 'Accent color', default: '#00e5ff' });
    let font = await RequestFontInput({ label: 'Headline font', options: ['Segoe UI', 'Cascadia Mono'] });
    let title = await RequestTextInput({
        label: 'Product title',
        validate: { required: true, minLength: 3, pattern: '^[A-Za-z0-9 ]+$' },
    });
    let servers = await RequestMultiSelectInput({
        label: 'Rollout servers',
        options: [{ value: 'SMPMD', checked: true }, 'iMedOne', 'ACM'],
    });

    // progress (determinate neon bar in the µGulp dashboard)
    let progress = CreateProgress('compiling theme');
    for (let step = 1; step <= 10; step++) {
        // ... work ...
        progress.Update(step / 10);
    }
    progress.Done();

    // sound + speech (rendered by the dashboard, configured in its settings)
    PlaySignal('success');              // preset → taskSuccess (also error→taskFailed, attention→requestAlert)
    PlaySound('taskSuccess');           // named atlas sample (see MicroGulpSoundSchema.md)
    PlaySound('engine', { loop: true }); // loop until StopSound('engine')
    StopSound('engine');
    Speak('Theme build finished.');
}
BUILD_THEME.µDisplayName = 'Build Theme<context="µDisplayName"/>'.i18xRegister();
BUILD_THEME.µDescription = 'Compiles the Carbon/Neon dashboard skin.<context="µDescription"/>'.i18xRegister();
```

Complete forms in one go:

```javascript
let values = await RequestForm({
    title: 'Build parameters',
    fields: [
        { id: 'mode',    type: 'radio',    label: 'Build mode', default: 'release', options: ['debug', 'release'] },
        { id: 'threads', type: 'range',    label: 'Worker threads', min: 1, max: 16, step: 1, default: 4 },
        { id: 'notes',   type: 'textarea', label: 'Release notes', rows: 4, placeholder: 'What changed?' },
        { id: 'apikey',  type: 'password', label: 'API key', validate: { required: true } },
        { id: 'targets', type: 'checkbox', label: 'Targets', options: ['Alpha', 'Beta', 'Gamma'], validate: { minSelected: 1 } },
    ],
});
// values => { mode: 'release', threads: '8', notes: '…', apikey: '…', targets: ['Alpha', 'Gamma'] }
```

## API reference

| Function | Purpose |
| :--- | :--- |
| `IsMicroGulp()` / `IsµGulp()` | `true` when the task runs under µGulp™ with an attached dashboard |
| `InstallStringExtensions()` | Installs µLib-compatible `String.prototype.i18xTrans()`/`i18xRegister()` and the Format prototypes (auto-run on import) |
| `InstallFormatPrototypes()` | Installs `Number`/`Date`/`String.prototype.Format()` (auto-run on import) |
| `Log(text, values?)` / `Warn` / `LogError` | Localized `console.*` via i18x (`<context="task log"/>` etc.) - preferred for task log output |
| `Translate(text, values?)` | Low-level: returns the translated string without logging (rarely needed directly) |
| `FormatValue(value, format, lid?, timeZone?)` | Formats a number/date with a named i18x format (`int`, `floatFix2`, `byteSize`, `stdDateTime`, …) |
| `(1536).Format('byteSize')` | Prototype sugar for `FormatValue`; `.FormatTimestamp()`/`.FormatTicks()` on numbers, `.Format()` on dates |
| `"phrase".i18xTrans(values?)` | Prototype sugar for `Translate` - same result, ergonomic in expressions |
| `"phrase".i18xRegister()` | Registers metadata text (returns the source phrase unchanged as the i18x key) |
| `GetLid()` / `SetLid(lid?)` | Active language id; `SetLid` clears to automatic when omitted |
| `ReportProgress(value, label?)` | Report progress `0..1` to the task progress bar |
| `CreateProgress(label?)` | Reporter object with `Update(value, stepLabel?)` and `Done()` |
| `PlaySignal(signal?)` | Preset or schema name; presets: `'success'`→`taskSuccess`, `'error'`→`taskFailed`, `'attention'`→`requestAlert` |
| `PlaySound(sample, options?)` | Named sample from the dashboard sound atlas (e.g. `taskStart`, `requestInfo`); `options.loop` repeats until `StopSound` |
| `StopSound(sample)` | Stops a looping sample started with `PlaySound(sample, { loop: true })` |
| `RegisterDashboardFont(spec)` | Registers a workspace font for dashboard task icons / run-log (`id`, `file`, optional `family` / `usage`: `task-icons`\|`log`\|`all`) |
| `GetRegisteredDashboardFonts()` | Snapshot of fonts registered in this process (scan worker / tests) |
| `ClearRegisteredDashboardFonts()` | Clears the in-process registry (tests) |
| `Speak(text, options?)` | Speech output in the dashboard; `options`: `{ rate?, pitch?, volume? }` per-call overrides |
| `RequestForm(form)` | Request a complete form; resolves with `{ fieldId: value, … }` |
| `ShowModalMessage(spec)` | Blocking modal (`info`/`warning`/`error`); `presentation`: `webview` \| `ide` \| `auto` |
| `ShowConfirmMessage(spec)` | Yes/No or OK/Cancel (`style`); resolves with `{ button }` |
| `RequestTextInput(options)` | Single text field (with `validate` rules) |
| `RequestColorInput(options)` | Color picker, returns `#rrggbb` |
| `RequestFontInput(options)` | Font selection (`options`: font list) |
| `RequestSelectInput(options)` | Single selection from a fixed option list |
| `RequestMultiSelectInput(options)` | Multi selection (checkbox group), always resolves to a `string[]` |
| `RequestFileInput(options)` | Filesystem file path (native picker in VS Code/Cursor/JetBrains; `accept` optional) |
| `RequestFolderInput(options)` | Filesystem folder path (`RequestDirectoryInput` is an alias) |
| `GetParameters()` | Values of the task's declared `µParameters` (map id → typed value) |
| `GetParameter(id, fallback?)` | Single declared parameter value, with an env fallback |
| `NotifyTasksChanged()` | Re-evaluates dynamic metadata (`µEnabled`, `µAttention`, tooltips) and refreshes the dashboard list |
| `SetGroupState(path, state, options?)` | Expands or collapses a µGroup in the **central** task tree (dashboard and hardware follow) |
| `RevealTask(task, options?)` | Opens parent groups and optionally highlights the task (`highlight: 'attention'`; `scroll`/`focus` are dashboard-only) |
| `SetTaskEmphasis(task, emphasis)` | Sets or clears emphasis independently of run status (`'attention'` or `null`) |
| `ReloadHostWindow()` | After a successful run, reload the VS Code/Cursor window (`Developer: Reload Window`); no-op in CLI/JetBrains/browser |
| `ScheduleTask(spec)` | Arms a session schedule (`{ id, task, after? \| every? \| cron?, repeat?, autoStart? }`); returns `true` when sent to µGulp |
| `SetScheduleEnabled(id, enabled)` / `CancelSchedule(id)` / `RunScheduleNow(id)` | Enable/disable, cancel or fire a schedule now (still via the normal task start; overlap and watch still skip) |
| `GetProjectControls()` | Project control values of this run (`{ id: string \| boolean }`), frozen at task start |
| `GetProjectControl(id, fallback?)` | Single project control value, with an env fallback |
| `Ide.*` | IDE and project API, see [IDE and project API](#ide-and-project-api) |
| `LogTable` / `LogTree` / `LogGallery` | Structured table, tree or image gallery in the run log |
| `LogCallout` / `LogKeyValue` / `LogBadges` / `LogCode` / `LogChart` | Callout, metrics, chips, code block, bar chart |
| `LogAccordion(spec)` | Collapsible accordion (`title?`, `items: { summary, lines?, body?, open? }[]`) |

### Declared task parameters (`µParameters`)

Instead of asking inside the task body, declare the inputs once and read them at the top of the task. µGulp shows one form before the run, remembers the answers for the next run and passes the values in as environment:

```javascript
import { GetParameters, Log } from 'gulp-mu-gulp-api';

export async function DEPLOY() {
    let { target, tag, dryRun } = GetParameters();
    Log('Deploying <tag/> to <target/><context="task log"/>', { tag, target });
}
DEPLOY.µParameters = [
    { id: 'target', type: 'select', options: ['staging', 'production'], default: 'staging' },
    { id: 'tag', type: 'text', required: true, pattern: '^v\\d+\\.\\d+' },
    { id: 'dryRun', type: 'boolean', default: true },
    { id: 'token', type: 'password' },   // never stored, never logged
];
```

The declaration uses the same field types as `RequestForm` plus the `boolean` slide switch. `id` must be env-var safe. Values arrive as `MICROGULP_PARAMS` (JSON) and `MICROGULP_PARAM_<ID>`, so shell steps in the task can read them as well. Gulp CLI does not apply `µParameters` defaults; set those variables yourself or pass a fallback to `GetParameter()`. Flat `MICROGULP_PARAM_*` values are strings:

```bash
MICROGULP_PARAM_TARGET=staging npx gulp DEPLOY
```

Large option lists on `select` / `radio` / `checkbox` are normalized by the µGulp host (default ceiling **5000**, override `MICROGULP_MAX_SELECT_OPTIONS`, `0` = unlimited). Truncation is never silent. See Field types below and the Host note under Changelog.

### Localized task metadata (`.i18xRegister()` + placeholders)

Write the i18xe context tag **into** the source phrase and mark it with `.i18xRegister()` - that marker is what the `i18xe-sync` tooling scans for, and at runtime it returns the phrase unchanged (the classic gulp CLI keeps seeing a plain string). Use i18xe placeholder tags in the source text. The dashboard substitutes a standard property set when translating:

| Placeholder | Source |
| :--- | :--- |
| `version` | `µI18xContext.version` export, else `package.json` |
| `project` | `µI18xContext.project` export, else `package.json` `name` |
| `workspace` | workspace folder name |
| `source` | gulpfile path relative to the workspace |
| `gulpfile` | gulpfile file name |
| `task` | technical export name |
| `taskId` | composite id `source::task` |
| `installed` | `µInstalledVersion` on that task (optional) |

Export defaults from the gulpfile (overrides `package.json`):

```javascript
export const µI18xContext = { version: '1.13', project: 'eMP' };

MAKE_BUILDS.µDisplayName = 'Make Build V<version/><context="µDisplayName"/>'.i18xRegister();
// => "Make Build V1.13" in the dashboard (translatable per language)
```

### Dashboard fonts (task icons & run log)

Project fonts are independent of the dashboard skin. Register them at gulpfile load time:

```javascript
import { RegisterDashboardFont } from 'gulp-mu-gulp-api';

RegisterDashboardFont({
    id: 'ProjectIcons',
    file: 'assets/task-icons.woff2', // relative to the gulpfile directory
    usage: 'task-icons',             // or 'log' / 'all'
});

BUILD.µIcon = '\uE101';
BUILD.µIconFont = 'ProjectIcons';   // optional when only one task-icons font is registered
```

Alternatively export `µDashboardFonts` from the gulpfile, or set `dashboardFonts` in `microgulp.config.json` / the `microgulp.dashboardFonts` extension setting. Files must stay under the workspace (`woff2` / `woff` / `ttf` / `otf`). The first `task-icons` font becomes the default for glyph `µIcon` entries; `usage: 'log'` restyles the run-sector log.

### Field types (for `RequestForm`)

A field descriptor is `{ id, type, label, default?, options?, validate?, min?, max?, step?, rows?, placeholder?, accept? }`.

| `type` | Dashboard control | Notes |
| :--- | :--- | :--- |
| `text` | text field | default type |
| `password` | masked text field | |
| `number` | number field | honors `min`, `max`, `step` |
| `textarea` | multi-line text field | `rows`, `placeholder` |
| `color` | native color picker | value as `#rrggbb` |
| `font` | font selection | `options`: font family names |
| `select` | dropdown | single choice |
| `radio` | radio group | single exclusive choice, vertical option column |
| `checkbox` | checkbox group | **multi-select** - resolves to a `string[]` |
| `range` | slider + synced number box | `min`, `max`, `step`, `default` |
| `date` / `time` / `datetime` | native date/time pickers | |
| `file` | path field + Browse | native OS file dialog in VS Code/Cursor/JetBrains; value is a filesystem path; optional `accept` (`.zip,.json`) |
| `folder` | path field + Browse | native OS folder dialog; `directory` is an alias |

**Options** (`select`, `radio`, `checkbox`) accept plain strings or objects `{ value, label?, checked?, disabled? }` - `checked` preselects checkbox options, `disabled` greys an option out.

Long option lists are fine for `RequestForm` (no host-side cap on the live form payload). Declarative `µParameters` are normalized by the µGulp host with a safety ceiling of **5000** options per field (override with `MICROGULP_MAX_SELECT_OPTIONS`; `0` / `unlimited` disables the cap). If a list is truncated, the dashboard shows an explicit warning (`Showing N of M options - list truncated`) instead of silently dropping entries. Selects with 24+ options also get a typeahead filter in the dashboard.

**Validation rules:** `{ required?, minLength?, pattern?, minSelected? }` (`minSelected` applies to `checkbox`). Checks run asynchronously in the dashboard; invalid forms cannot be submitted.

## Fallback behavior without µGulp™

| Function | TTY (interactive shell) | non-TTY (CI, pipe) |
| :--- | :--- | :--- |
| `ReportProgress` | updating progress line | log line every 10% step |
| `PlaySignal` | terminal bell (`attention`/`error`) | silent |
| `PlaySound` / `StopSound` | `[sound] <name>` log line | silent |
| `Speak` | `[speech]` log line | `[speech]` log line |
| text/password/number/range input | readline prompt (Enter = default) | default value |
| font/select/radio input | numbered list + readline | default value |
| checkbox input | numbered list, comma-separated picks | values of the `checked` options |
| `file` / `folder` input | readline prompt for a path | default value |
| `ShowModalMessage` / `ShowConfirmMessage` | console line, returns `{ button: 'ok' }` | same - not a CLI approval |

Sound and speech playback (mute, volume, speech rate/pitch) is configured centrally in the µGulp™ dashboard settings (gear icon in the header) - tasks never need to care about the user's audio preferences.

## License

MIT - © 2026 Meinolf Amekudzi

### Publishing (maintainers)

npm accounts with 2FA reject `npm publish` with `EOTP` when `~/.npmrc` holds a
web-login session token (`npm login --auth-type=web`). The reliable fix is a
**Granular Access Token** with **Bypass 2FA** and **write** access to this package:

1. npmjs.com → Access Tokens → Generate → Granular
2. Permissions: **Read and write**, Packages: `gulp-mu-gulp-api` (or All packages)
3. Enable **Bypass 2FA**, copy the token, then:

```powershell
npm config set //registry.npmjs.org/:_authToken <TOKEN>
```

After that, publish without any OTP:

```powershell
npm run publish:api
```

Bump `gulp-mu-gulp-api/package.json` before publishing. The task runs the module
tests first. As a one-off, a 2FA code still works via `NPM_OTP`:

```powershell
$env:NPM_OTP="123456"; npm run publish:api
```

---

# Deutsch

## 0.8.0 - Task-Laufkontext

`GetTaskRunContext()` liefert den Auslöser des aktuellen Task-Laufs, zum Beispiel `{ reason: 'schedule', scheduleId: 'backup-daily' }`. Manuelle Läufe und die normale Gulp-CLI liefern `{ reason: 'manual' }`. Der Kontext gilt nur für den jeweiligen Task-Aufruf und wird zurückgesetzt, bevor ein warmer Worker wiederverwendet wird. Diese additive API benötigt µGulp 1.2.0 oder neuer; ältere Hosts stellen keine Zeitplan-Auslöser bereit.

<p align="center">
  <a href="https://microgulp.dev/de/#%C2%B5gulp-ready">
    <img src="https://microgulp.dev/assets/media/microgulp-ready.png" alt="µGulp Ready" width="110">
  </a>
</p>

<p align="center"><strong>Rock your Gulp!</strong><br/>
µGulp™ - der interaktive Task-Orchestrator mit nahezu null Latenz, stylischer Dashboard-Ausgabe, Webview-Steuerung und akustischem Feedback.</p>

**gulp-mu-gulp-api** ist die öffentliche Task-API des **µGulp™**-Orchestrators. Gulp-Tasks (und beliebige npm-Pakete innerhalb des Task-Streams) erhalten damit Zugriff auf die erweiterten µGulp™-Dashboard-Funktionen: Fortschrittsanzeige, i18x-Konsolenausgabe, Texteingaben mit Validierung, Farb- und Schriftart-Auswahl, Einzel- und Mehrfachauswahl, Slider und komplette Formulare.

[![npm version](https://img.shields.io/npm/v/gulp-mu-gulp-api.svg)](https://www.npmjs.com/package/gulp-mu-gulp-api) · [µGulp™](https://microgulp.dev) · [Support](mailto:support@microgulp.dev)

Das Modul ist bewusst **abhängigkeitsfrei** und kennt keine µGulp™-Interna: Läuft der Task unter µGulp™, spricht es direkt über den IPC-Kanal des Worker-Prozesses mit der Engine. Läuft das Gulpfile klassisch über die gulp-CLI, degradieren alle Funktionen sauber - Fortschritt landet auf dem Terminal, Eingaben werden per readline abgefragt (TTY) oder mit den deklarierten Default-Werten beantwortet (CI/non-TTY). Tasks bleiben ohne µGulp™ voll lauffähig.

## Installation

```bash
npm install gulp-mu-gulp-api
```

### 0.6.0

- **Neu** `Ide.Projects()`, `Ide.Action(id)`, `Ide.OpenProject(request)` und `Ide.StartApplication(applicationId)` - bekannte Projekte, semantische IDE-Aktionen, Open/Focus Project und ausdrücklich konfigurierte Anwendungen. Siehe [IDE- und Projekt-API](#ide--und-projekt-api).
- **Neu** `ScheduleTask(spec)`, `SetScheduleEnabled(id, enabled)`, `CancelSchedule(id)` und `RunScheduleNow(id)` - imperatives Gegenstück zur Task-Metadate `µSchedule` (Sitzungs-Schedules; jeder Lauf geht weiterhin über den normalen Taskstart).
- **Neu** `GetProjectControls()` / `GetProjectControl(id, fallback?)` - Werte der Project-Controls-Leiste (`select` / `radio` / `checkbox`), beim Laufstart eingefroren. Außerhalb von µGulp: `MICROGULP_CONTROLS` (JSON) oder `MICROGULP_CONTROL_<ID>`.
- Rein additiv: alle Exporte und Signaturen aus 0.5.0 bleiben unverändert. Die neuen Funktionen brauchen µGulp™ **1.0.0** oder neuer; ältere Hosts beantworten IDE-Aufrufe mit einem Fehlerergebnis, Schedule-Aufrufe bleiben wirkungslos, Project Controls sind leer.

### 0.5.0

- **Neu** `LogAccordion({ title?, items })` - klappbare Abschnitte im Run-Log (`summary` + `lines` / `body`, optional `open`). Das Dashboard rendert native `<details>` mit Alle aufklappen/zuklappen bei mehreren Einträgen. CLI-Fallback: betitelte Aufzählungen auf stdout.
- Benötigt ein passendes µGulp-Dashboard mit Structured-Log-Format `accordion` (aktuelle µGulp-Pakete). Ältere Hosts ignorieren unbekannte Formate.

### Host-Hinweis (µGulp 0.9.6+) - kein API-Bump

- Lange `select`-/`radio`-/`checkbox`-Optionslisten: `RequestForm` sendet weiterhin die volle Payload (kein Cap in dieser API). Deklarative `µParameters` normalisiert der **Host** mit einer Sicherheitsgrenze von **5000** Optionen pro Feld (vorher still 200). Override: `MICROGULP_MAX_SELECT_OPTIONS` (`0` / `unlimited` = kein Cap). Truncation setzt Host-Metadaten; das Dashboard warnt statt still zu kürzen. Selects mit 24+ Optionen erhalten einen Typeahead-Filter. Details: Abschnitt Feldtypen unten bzw. `dev/docs/RequestFormOptions.md` im µGulp-Repo.
- Keine neuen Exports und keine Breaking Changes in diesem Paket - Host/Extension aktualisieren, damit das Verhalten greift.

### 0.4.3

- **Aktualisiert** Ready-Badge auf die veröffentlichte Seite `/en/ready/` (110 Pixel, ohne feste Höhe) und den tatsächlichen CLI-Rückfall: `ShowModalMessage()` / `ShowConfirmMessage()` liefern `{ button: 'ok' }`; die Gulp-CLI übernimmt `µParameters`-Defaults nicht.
- **Neu** Dateisystem-Pfadauswahl: Feldtypen `file` und `folder` (Alias `directory`), `RequestFileInput()` / `RequestFolderInput()`, dieselben Typen in `µParameters`. Das Dashboard zeigt ein Pfadfeld plus Durchsuchen (nativer OS-Dialog in VS Code, Cursor und JetBrains-IDEs). Der Wert ist der echte Pfad, kein Browser-`fakepath`.
- **Neu** `ReloadHostWindow()` - nach einem erfolgreichen Lauf das VS-Code-/Cursor-Fenster neu laden (`Developer: Reload Window`); wirkungslos in der gulp-CLI, unter JetBrains und in der Browser-Demo.
- **Aktualisiert** `NotifyTasksChanged()` wertet im Dashboard auch `µAttention` / `µAttentionTooltip` neu aus, nicht nur `µEnabled` und Tooltips.

### 0.4.2

- **Aktualisiert** Homepage, Support und README-Bilder auf die öffentliche Seite [microgulp.dev](https://microgulp.dev) und [support@microgulp.dev](mailto:support@microgulp.dev). Das Quellrepository ist privat.

### 0.4.1

- **Behoben** Ein Platzhalter mit unbekanntem benanntem Format wurde als leerer Text gerendert statt mit seinem Wert - den Gulp-Lifecycle-Zeilen fehlte dadurch die Dauer (`Finished 'task' after`). Fehlt das Format, bleibt der Rohwert erhalten.
- **Behoben** `SetLid()` behielt das Wörterbuch der vorherigen Sprache im Cache; ein Sprachwechsel im laufenden Worker konnte weiter mit veralteten Texten übersetzen.

### 0.4.0

- **Neu** `GetParameters()` / `GetParameter(id, fallback)` - Werte für die Eingaben, die ein Task per `µParameters` deklariert hat. µGulp fragt sie einmal vor dem Task-Rumpf ab und übergibt sie als `MICROGULP_PARAMS` (JSON) plus je Parameter ein flaches `MICROGULP_PARAM_<ID>`.
- Funktioniert auch ohne µGulp: dieselben Umgebungsvariablen von Hand setzen (`MICROGULP_PARAM_TARGET=staging npx gulp DEPLOY`) oder einen Rückfallwert an `GetParameter()` übergeben. Die Gulp-CLI übernimmt `µParameters`-Defaults nicht automatisch; flache Umgebungswerte sind Zeichenketten.
- Ergänzende Gulpfile-Metadaten aus µGulp 0.7.0: `µParameters` (deklarative Eingaben), `µKeyBinding` (Dashboard-Kürzel), `µWatch` (Datei-Trigger). Reine Task-Eigenschaften - kein API-Aufruf nötig.

### 0.3.13

- **Aktualisiert** `PlaySignal` / `PlaySound` für das µGulp-Sound-Schema (`taskSuccess`, `taskFailed`, `requestAlert`, …). Legacy-Presets `success` / `error` / `attention` bleiben gültig.

### 0.3.12

- **Neu** `RegisterDashboardFont({ id, file, family?, usage? })` - registriert einen Workspace-Font für **Task-Icons** und/oder die **Run-Log**-Typografie im µGulp-Dashboard. `usage`: `'task-icons'` (Default), `'log'` oder `'all'`. Aufruf beim Laden des Gulpfiles; der Scan-Worker reicht die Registry an die Engine weiter.
- **Neu** `GetRegisteredDashboardFonts()` / `ClearRegisteredDashboardFonts()` - Snapshot- bzw. Test-Helfer.
- Zusammen mit Metadaten `µIcon` (Glyph) und optional `µIconFont = '<id>'`, oder deklarativ `export const µDashboardFonts = […]`. Alternative: `dashboardFonts` in Config/Setting.
- Außerhalb von µGulp sind die Helfer No-ops (Fonts sind Sache von Dashboard/Host).

### 0.3.11

- **Neu** `ShowModalMessage({ variant?, title?, message?, buttons?, presentation? })` - blockierendes Modal (info/warning/error) als Dashboard-Glaspanel oder natives VS-Code-/Cursor-Dialogfenster bei `presentation` `ide`/`auto` (Host-Setting `microgulp.modalPresentation`).
- **Neu** `ShowConfirmMessage({ title?, message?, variant?, style?, presentation? })` - Ja/Nein- oder OK/Abbrechen-Bestätigung; Ergebnis `{ button: 'yes'|'no'|'ok'|'cancel'|… }`.
- Außerhalb von µGulp schreiben beide Helfer eine Konsolenzeile und geben `{ button: 'ok' }` zurück. Das ist keine CLI-Freigabe - für folgenreiche Aktionen eine ausdrückliche Option verlangen oder abbrechen.

### 0.3.10

- **Fixed** `IsMicroGulp()` / `IsµGulp()` - returns `true` only when `MICROGULP=1` **and** `typeof process.send === 'function'`. Child processes that inherit `MICROGULP` without an IPC channel (nested gulp runs, test subprocesses) no longer crash on `process.send`.

### 0.3.8

- **Neu** strukturierte Log-Elemente, die direkt im Run-Log gerendert werden (JSON-Payloads, Content-Security-Policy-sicher, ohne Plugin/iframe): `LogCallout()` (Info/Success/Warning/Error-Box), `LogKeyValue()` (Metriken/Zusammenfassung), `LogBadges()` (Status-Chips), `LogCode()` (Monospace-Codeblock) und `LogChart()` (Inline-SVG-Balkendiagramm).
- Jeder neue Helfer fällt außerhalb von µGulp auf eine lesbare stdout-Ausgabe zurück (Callout in Klammern, ausgerichtete Key/Value-Zeilen, Badges in Klammern, Code wortgetreu, ASCII-Balkendiagramm).

### 0.3.7

- **Neu** Engine-Datum/Zeit-Platzhalter: `weekofyear`, `dayofyear`, `utcweekofyear`, `utcdayofyear`, `timezoneoffset`, `timezoneshort`, `timezoneplace`.
- **Neu** `TimeZoneOffset()` - JavaScript-kompatibler Offset in Minuten (gleiches Vorzeichen wie `Date.getTimezoneOffset()`).
- **Neu** Silbentrennungs-API: `WordHyphenation()`, `Hyphenation()`, `LoadHyphenData()`, `InstallHyphenPrototypes()` mit µLib- (`WordHyphenation`/`Hyphenation`) und i18xe-sync-Aliasen (`wordHyphenation`/`hyphenation`); ohne `<lid>.hyphen.json`-Daten No-op.
- **Neu** i18xe-sync-Lowercase-Format-Aliase: `Number.prototype.format()` / `.formatTimestamp()` / `.formatTicks()`, `Date.prototype.format()`.
- **Geändert** `Translate(text, values?, timeZone?)` und `.i18xTrans(values?, timeZone?)` akzeptieren optional eine IANA-Zeitzone.

### 0.3.6

- **Neu** vollständige eval-freie i18x-Engine (`i18x-engine.mjs`): `FormatValue()`/`Translate()` beherrschen jetzt die komplette i18x-Notation - `if`/`ifnot`/`ifin`-Bedingungen, verschachtelte Formate, `expression="…"`, Enumerationen, Ziffern-Fill/Padding, Datum/Zeit-Teile und römische Zahlen.
- **Neu** µLib-kompatible `Number.prototype.Format()`, `Number.prototype.FormatTimestamp()`, `Number.prototype.FormatTicks()`, `Date.prototype.Format()` und `String.prototype.Format()` (werden beim Import automatisch installiert; siehe `InstallFormatPrototypes()`).
- **Geändert** `FormatValue(value, format, lid?, timeZone?)` um das optionale `timeZone`-Argument erweitert; Datum/Zeit-Formate interpretieren den Wert als Unix-Millisekunden.

### 0.3.5

- **Neu** `PlaySound(sample, { loop? })` und `StopSound(sample)` - benannte Samples aus dem Dashboard-µAU-Sound-Atlas; `loop: true` wiederholt bis `StopSound`.
- **Geändert** npm-README: klarere i18x-Sektion (`Log`/`Warn` vs. `.i18xTrans()` / `.i18xRegister()`).

### 0.3.3

- **Geändert** npm-README: zentriertes µGulp-Logo und µGulp-ready-Badge (absolute raw-URLs aus dem µGulp-Repo).

### 0.3.2

- **Neu** `FormatValue()` - rendert `<name format="…"/>`-Platzhalter aus `<format …>`-XML-Definitionen in `i18x/gulp/<lid>.json` des Verbraucherprojekts.
- **Geändert** Format-IDs auf CamelCase (`floatFix2`, `stdDate`, `progressDuration`, `byteSize`, …); Lifecycle-Dauer-Logs erwarten Roh-Millisekunden mit `format="progressDuration"`.

### 0.3.0

- **Neu** integrierte i18x-Konsolenschicht: `Log`, `Warn`, `LogError`, `Translate`, `GetLid`, `SetLid`, `GetTimeZone`, `DateInTimeZone`, `InstallStringExtensions` - Übersetzungen liegen im Verbraucherprojekt unter `i18x/gulp/<lid>.json`; die Sprache folgt `MICROGULP_LANG` (vom µGulp-Dashboard gesetzt) mit Locale-Fallback.
- **Neu** µLib-kompatible `String.prototype.i18xTrans()` / `.i18xRegister()` (werden beim Import automatisch installiert).
- **Entfernt** `µMeta()` / `MicroGulpMeta` - Kontext-Tag in die Textphrase schreiben und `.i18xRegister()` verwenden (siehe unten).

## Verwendung

```javascript
import { ReportProgress, CreateProgress, PlaySignal, PlaySound, StopSound, Speak, RequestTextInput, RequestColorInput, RequestFontInput, RequestSelectInput, RequestMultiSelectInput, RequestForm, RegisterDashboardFont, IsMicroGulp, IsµGulp, InstallStringExtensions } from 'gulp-mu-gulp-api';

// Enables "phrase<context=\"…\"/>".i18xRegister()/.i18xTrans() on strings.
InstallStringExtensions();

export async function BUILD_THEME() {
    // Einzeleingaben
    let accent = await RequestColorInput({ label: 'Accent color', default: '#00e5ff' });
    let font = await RequestFontInput({ label: 'Headline font', options: ['Segoe UI', 'Cascadia Mono'] });
    let title = await RequestTextInput({
        label: 'Product title',
        validate: { required: true, minLength: 3, pattern: '^[A-Za-z0-9 ]+$' },
    });
    let servers = await RequestMultiSelectInput({
        label: 'Rollout servers',
        options: [{ value: 'SMPMD', checked: true }, 'iMedOne', 'ACM'],
    });

    // Fortschritt (determinierte Neon-Progressbar im µGulp-Dashboard)
    let progress = CreateProgress('compiling theme');
    for (let step = 1; step <= 10; step++) {
        // ... Arbeit ...
        progress.Update(step / 10);
    }
    progress.Done();

    // sound + speech (rendered by the dashboard, configured in its settings)
    PlaySignal('success');              // preset → taskSuccess (also error→taskFailed, attention→requestAlert)
    PlaySound('taskSuccess');           // named atlas sample (see MicroGulpSoundSchema.md)
    PlaySound('engine', { loop: true }); // loop until StopSound('engine')
    StopSound('engine');
    Speak('Theme build finished.');
}
BUILD_THEME.µDisplayName = 'Build Theme<context="µDisplayName"/>'.i18xRegister();
BUILD_THEME.µDescription = 'Kompiliert den Carbon/Neon-Dashboard-Skin.<context="µDescription"/>'.i18xRegister();
```

Komplette Formulare in einem Rutsch:

```javascript
let values = await RequestForm({
    title: 'Build parameters',
    fields: [
        { id: 'mode',    type: 'radio',    label: 'Build mode', default: 'release', options: ['debug', 'release'] },
        { id: 'threads', type: 'range',    label: 'Worker threads', min: 1, max: 16, step: 1, default: 4 },
        { id: 'notes',   type: 'textarea', label: 'Release notes', rows: 4, placeholder: 'What changed?' },
        { id: 'apikey',  type: 'password', label: 'API key', validate: { required: true } },
        { id: 'targets', type: 'checkbox', label: 'Targets', options: ['Alpha', 'Beta', 'Gamma'], validate: { minSelected: 1 } },
    ],
});
// values => { mode: 'release', threads: '8', notes: '…', apikey: '…', targets: ['Alpha', 'Gamma'] }
```

## API-Referenz

| Funktion | Zweck |
| :--- | :--- |
| `IsMicroGulp()` / `IsµGulp()` | `true`, wenn der Task unter µGulp™ mit angebundenem Dashboard läuft |
| `InstallStringExtensions()` | Installiert µLib-kompatible `String.prototype.i18xTrans()`/`i18xRegister()` und die Format-Prototypes (läuft beim Import automatisch) |
| `InstallFormatPrototypes()` | Installiert `Number`/`Date`/`String.prototype.Format()` (läuft beim Import automatisch) |
| `FormatValue(value, format, lid?, timeZone?)` | Formatiert Zahl/Datum mit einem benannten i18x-Format (`int`, `floatFix2`, `byteSize`, `stdDateTime`, …) |
| `(1536).Format('byteSize')` | Prototype-Kurzform für `FormatValue`; `.FormatTimestamp()`/`.FormatTicks()` an Zahlen, `.Format()` an Dates |
| `Log(text, values?)` / `Warn` / `LogError` | Lokalisierte `console.*`-Ausgabe über i18x - bevorzugt für Task-Logs |
| `Translate(text, values?)` | Low-Level: übersetzter String ohne Log (selten direkt nötig) |
| `"phrase".i18xTrans(values?)` | Prototype-Kurzform für `Translate` |
| `"phrase".i18xRegister()` | Metadaten-Text registrieren (gibt die Quellphrase unverändert zurück) |
| `GetLid()` / `SetLid(lid?)` | Aktive Sprach-ID; `SetLid` ohne Argument = automatische Auflösung |
| `ReportProgress(value, label?)` | Fortschritt `0..1` an die Task-Progressbar melden |
| `CreateProgress(label?)` | Reporter-Objekt mit `Update(value, stepLabel?)` und `Done()` |
| `PlaySignal(signal?)` | Vorgabe oder Schema-Name; Presets: `'success'`→`taskSuccess`, `'error'`→`taskFailed`, `'attention'`→`requestAlert` |
| `PlaySound(sample, options?)` | Benanntes Sample aus dem Sound-Atlas (z. B. `taskStart`, `requestInfo`); `options.loop` wiederholt bis `StopSound` |
| `StopSound(sample)` | Stoppt eine Schleife von `PlaySound(sample, { loop: true })` |
| `RegisterDashboardFont(spec)` | Registriert einen Workspace-Font für Dashboard-Task-Icons / Run-Log (`id`, `file`, optional `family` / `usage`: `task-icons`\|`log`\|`all`) |
| `GetRegisteredDashboardFonts()` | Snapshot der in diesem Prozess registrierten Fonts (Scan-Worker / Tests) |
| `ClearRegisteredDashboardFonts()` | Leert die In-Process-Registry (Tests) |
| `Speak(text, options?)` | Sprachausgabe im Dashboard; `options`: `{ rate?, pitch?, volume? }` je Aufruf |
| `RequestForm(form)` | Komplettes Formular anfordern; löst mit `{ fieldId: value, … }` auf |
| `ShowModalMessage(spec)` | Blockierendes Modal (`info`/`warning`/`error`); `presentation`: `webview` \| `ide` \| `auto` |
| `ShowConfirmMessage(spec)` | Ja/Nein oder OK/Abbrechen (`style`); löst mit `{ button }` auf |
| `RequestTextInput(options)` | Einzelnes Textfeld (mit `validate`-Regeln) |
| `RequestColorInput(options)` | Farbwähler, Rückgabe `#rrggbb` |
| `RequestFontInput(options)` | Schriftart-Auswahl (`options`: Font-Liste) |
| `RequestSelectInput(options)` | Einzelauswahl aus fester Optionsliste |
| `RequestMultiSelectInput(options)` | Mehrfachauswahl (Checkbox-Gruppe), löst immer mit `string[]` auf |
| `RequestFileInput(options)` | Dateisystem-Dateipfad (nativer Dialog in VS Code/Cursor/JetBrains; `accept` optional) |
| `RequestFolderInput(options)` | Dateisystem-Ordnerpfad (`RequestDirectoryInput` ist ein Alias) |
| `GetParameters()` | Werte der per `µParameters` deklarierten Task-Eingaben (Map id → typisierter Wert) |
| `GetParameter(id, fallback?)` | Einzelner deklarierter Parameterwert, mit Env-Fallback |
| `NotifyTasksChanged()` | Wertet dynamische Metadaten (`µEnabled`, `µAttention`, Tooltips) neu aus und aktualisiert die Task-Liste |
| `SetGroupState(path, state, options?)` | Klappt eine µGroup im **zentralen** Taskbaum auf oder zu (Dashboard und Hardware folgen) |
| `RevealTask(task, options?)` | Öffnet Parent-Gruppen und hebt den Task optional hervor (`highlight: 'attention'`; `scroll`/`focus` nur Dashboard) |
| `SetTaskEmphasis(task, emphasis)` | Setzt oder entfernt Emphasis unabhängig vom Laufstatus (`'attention'` oder `null`) |
| `ReloadHostWindow()` | Nach erfolgreichem Lauf das VS-Code-/Cursor-Fenster neu laden (`Developer: Reload Window`); wirkungslos in CLI/JetBrains/Browser |
| `ScheduleTask(spec)` | Schaltet einen Sitzungs-Schedule scharf (`{ id, task, after? \| every? \| cron?, repeat?, autoStart? }`); `true`, wenn an µGulp gesendet |
| `SetScheduleEnabled(id, enabled)` / `CancelSchedule(id)` / `RunScheduleNow(id)` | Schedule ein-/ausschalten, abbrechen oder sofort auslösen (weiterhin über den normalen Taskstart; Überlappung und Watch überspringen) |
| `GetProjectControls()` | Project-Control-Werte dieses Laufs (`{ id: string \| boolean }`), beim Taskstart eingefroren |
| `GetProjectControl(id, fallback?)` | Einzelner Project-Control-Wert, mit Env-Fallback |
| `Ide.*` | IDE- und Projekt-API, siehe [IDE- und Projekt-API](#ide--und-projekt-api) |
| `LogTable` / `LogTree` / `LogGallery` | Strukturierte Tabelle, Baum oder Bildergalerie im Run-Log |
| `LogCallout` / `LogKeyValue` / `LogBadges` / `LogCode` / `LogChart` | Callout, Metriken, Chips, Codeblock, Balkendiagramm |
| `LogAccordion(spec)` | Klappbares Akkordeon (`title?`, `items: { summary, lines?, body?, open? }[]`) |

### Deklarierte Task-Parameter (`µParameters`)

Statt im Task-Rumpf zu fragen, werden die Eingaben einmal deklariert und am Task-Anfang gelesen. µGulp zeigt vor dem Lauf ein Formular, merkt die Antworten für den nächsten Lauf und übergibt die Werte als Umgebung:

```javascript
import { GetParameters, Log } from 'gulp-mu-gulp-api';

export async function DEPLOY() {
    let { target, tag, dryRun } = GetParameters();
    Log('Deploying <tag/> to <target/><context="task log"/>', { tag, target });
}
DEPLOY.µParameters = [
    { id: 'target', type: 'select', options: ['staging', 'production'], default: 'staging' },
    { id: 'tag', type: 'text', required: true, pattern: '^v\\d+\\.\\d+' },
    { id: 'dryRun', type: 'boolean', default: true },
    { id: 'token', type: 'password' },   // wird nie gespeichert oder geloggt
];
```

Die Deklaration nutzt die Feldtypen von `RequestForm` plus die Kurzform `boolean` (Schiebeschalter). `id` muss als Umgebungsvariablenname taugen. Die Werte kommen als `MICROGULP_PARAMS` (JSON) und `MICROGULP_PARAM_<ID>` an - auch Shell-Schritte im Task können sie lesen. Die Gulp-CLI übernimmt `µParameters`-Defaults nicht; die Variablen selbst setzen oder einen Rückfallwert an `GetParameter()` übergeben. Flache `MICROGULP_PARAM_*`-Werte sind Zeichenketten:

```bash
MICROGULP_PARAM_TARGET=staging npx gulp DEPLOY
```

Lange Optionslisten an `select` / `radio` / `checkbox` normalisiert der µGulp-Host (Standardgrenze **5000**, Override `MICROGULP_MAX_SELECT_OPTIONS`, `0` = unbegrenzt). Truncation ist nie still. Siehe Feldtypen unten und den Host-Hinweis unter Changelog.

### Lokalisierte Task-Metadaten (`.i18xRegister()` + Platzhalter)

Den i18xe-Kontext-Tag **in** die Textphrase schreiben und mit `.i18xRegister()` markieren - genau diese Markierung scannt das `i18xe-sync`-Tooling, zur Laufzeit gibt sie den Text unverändert zurück (die klassische gulp-CLI sieht weiterhin einen einfachen String). i18xe-Platzhalter im Quelltext verwenden. Beim Übersetzen setzt das Dashboard einen Standardsatz ein:

| Platzhalter | Quelle |
| :--- | :--- |
| `version` | `µI18xContext.version`-Export, sonst `package.json` |
| `project` | `µI18xContext.project`-Export, sonst `package.json` `name` |
| `workspace` | Workspace-Ordnername |
| `source` | Gulpfile-Pfad relativ zum Workspace |
| `gulpfile` | Gulpfile-Dateiname |
| `task` | technischer Exportname |
| `taskId` | zusammengesetzte Id `source::task` |
| `installed` | `µInstalledVersion` an diesem Task (optional) |

Defaults im Gulpfile exportieren (`package.json` wird überschrieben):

```javascript
export const µI18xContext = { version: '1.13', project: 'eMP' };

MAKE_BUILDS.µDisplayName = 'Make Build V<version/><context="µDisplayName"/>'.i18xRegister();
// => „Make Build V1.13“ im Dashboard (pro Sprache übersetzbar)
```

### Dashboard-Fonts (Task-Icons & Run-Log)

Projekt-Fonts sind unabhängig vom Dashboard-Skin. Beim Laden des Gulpfiles registrieren:

```javascript
import { RegisterDashboardFont } from 'gulp-mu-gulp-api';

RegisterDashboardFont({
    id: 'ProjectIcons',
    file: 'assets/task-icons.woff2', // relativ zum Gulpfile-Ordner
    usage: 'task-icons',             // oder 'log' / 'all'
});

BUILD.µIcon = '\uE101';
BUILD.µIconFont = 'ProjectIcons';   // optional, wenn nur ein task-icons-Font registriert ist
```

Alternativ `µDashboardFonts` aus dem Gulpfile exportieren oder `dashboardFonts` in `microgulp.config.json` / Setting `microgulp.dashboardFonts`. Dateien müssen unter dem Workspace liegen (`woff2` / `woff` / `ttf` / `otf`). Der erste `task-icons`-Font ist Default für Glyph-`µIcon`; `usage: 'log'` setzt die Run-Log-Schrift.

### Feldtypen (für `RequestForm`)

Ein Feld-Deskriptor ist `{ id, type, label, default?, options?, validate?, min?, max?, step?, rows?, placeholder?, accept? }`.

| `type` | Dashboard-Steuerelement | Hinweise |
| :--- | :--- | :--- |
| `text` | Textfeld | Standardtyp |
| `password` | maskiertes Textfeld | |
| `number` | Zahlenfeld | berücksichtigt `min`, `max`, `step` |
| `textarea` | mehrzeiliges Textfeld | `rows`, `placeholder` |
| `color` | nativer Farbwähler | Wert als `#rrggbb` |
| `font` | Schriftart-Auswahl | `options`: Font-Familiennamen |
| `select` | Dropdown | Einzelauswahl |
| `radio` | Radiogruppe | exklusive Einzelauswahl, vertikale Optionsspalte |
| `checkbox` | Checkbox-Gruppe | **Mehrfachauswahl** - löst mit `string[]` auf |
| `range` | Slider + synchronisiertes Zahlenfeld | `min`, `max`, `step`, `default` |
| `date` / `time` / `datetime` | native Datums-/Zeitwähler | |
| `file` | Pfadfeld + Durchsuchen | nativer Dateidialog in VS Code/Cursor/JetBrains; Wert ist ein Dateisystempfad; optional `accept` (`.zip,.json`) |
| `folder` | Pfadfeld + Durchsuchen | nativer Ordnerdialog; `directory` ist ein Alias |

**Options** (`select`, `radio`, `checkbox`) akzeptieren einfache Strings oder Objekte `{ value, label?, checked?, disabled? }` - `checked` selektiert Checkbox-Optionen vor, `disabled` graut eine Option aus.

Lange Optionslisten sind für `RequestForm` unproblematisch (kein Host-Cap auf dem Live-Formular). Deklarative `µParameters` normalisiert der µGulp-Host mit einer Sicherheitsgrenze von **5000** Optionen pro Feld (Override: `MICROGULP_MAX_SELECT_OPTIONS`; `0` / `unlimited` schaltet das Cap ab). Bei Truncation zeigt das Dashboard eine Warnung (`Showing N of M options - list truncated`) statt still zu kürzen. Selects mit 24+ Optionen erhalten zusätzlich einen Typeahead-Filter.

**Validierungsregeln:** `{ required?, minLength?, pattern?, minSelected? }` (`minSelected` gilt für `checkbox`). Die Prüfung läuft asynchron im Dashboard; ungültige Formulare können nicht abgeschickt werden.

## Fallback-Verhalten ohne µGulp™

| Funktion | TTY (interaktive Shell) | non-TTY (CI, Pipe) |
| :--- | :--- | :--- |
| `ReportProgress` | aktualisierende Fortschrittszeile | Log-Zeile je 10-%-Schritt |
| `PlaySignal` | Terminal-Glocke (`attention`/`error`) | stumm |
| `PlaySound` / `StopSound` | `[sound]`-Log-Zeile | stumm |
| `Speak` | `[speech]`-Log-Zeile | `[speech]`-Log-Zeile |
| Text-/Passwort-/Zahlen-/Range-Eingabe | readline-Prompt (Enter = Default) | Default-Wert |
| Font-/Select-/Radio-Eingabe | nummerierte Liste + readline | Default-Wert |
| Checkbox-Eingabe | nummerierte Liste, Kommaeingabe | Werte der `checked`-Optionen |
| `file` / `folder`-Eingabe | readline-Prompt für einen Pfad | Default-Wert |
| `ShowModalMessage` / `ShowConfirmMessage` | Konsolenzeile, Rückgabe `{ button: 'ok' }` | dasselbe - keine CLI-Freigabe |

Die Sound- und Sprachwiedergabe (Mute, Lautstärke, Sprechgeschwindigkeit/-höhe) wird zentral in den µGulp™-Dashboard-Settings konfiguriert (Zahnrad im Kopfbereich) - Tasks müssen sich um die Audio-Einstellungen der Anwender nicht kümmern.

## Lizenz

MIT - © 2026 Meinolf Amekudzi

## Task presentation metadata / Metadaten zur Task-Darstellung

Task presentation is handled by the µGulp™ host. Existing `µIcon` glyphs or images and `µIconFont` stay supported. Use `µAttention` and `µAttentionTooltip` to mark required work independently of execution state. Optional `µAttentionWatch` triggers re-evaluation without executing the task. Explicit `µExecutionType = 'persistent'` marks a long-running task; `µWatch` remains a file trigger for separate runs.

Supported dashboard input requests can put an active run into `waiting-for-input`; task code must use the existing input helpers, not set presentation state itself. A log line saying “waiting” does not create an input request. Inputs collected before execution are distinct from a running task waiting for an answer.

Die Darstellung wird vom Host gesteuert. Eigene Glyphen bleiben erhalten; Attention kennzeichnet Handlungsbedarf, nicht den Laufzustand. Ein persistenter Task und ein aktivierter Dateitrigger sind unterschiedliche Konzepte. Die neuen Metadaten führen keinen eigenständigen Hardwarezugriff aus; dafür gelten die Berechtigungen des Hosts.

Examples and integration status / Beispiele und Integrationsstand: [presentation contract](../dev/docs/TaskPresentationAndHardware.md).


## IDE and project API

`import { Ide } from 'gulp-mu-gulp-api';` - every call returns a promise of `{ ok, result?, code?, message? }` and never throws. Without µGulp (plain gulp CLI) the result is `{ ok: false, code: 'unsupported-host' }`. Error codes are exported as `IDE_ERROR_CODES` (`unsupported-edition`, `unsupported-host`, `unsupported-operation`, `incompatible-host`, `command-not-allowed`, `command-failed`, `timeout`).

| Function | Purpose |
| :--- | :--- |
| `Ide.Capabilities()` | Host snapshot: `protocol`, `hostFamily`, `edition`, `operations`, semantic `actions` |
| `Ide.Execute({ vscode?, jetbrains?, args? })` | Portable command: one id per host family, no implicit rewriting |
| `Ide.Vscode.ExecuteCommand(id, ...args)` | VS Code / Cursor command (fails on JetBrains and browser hosts) |
| `Ide.JetBrains.ExecuteAction(id)` | IntelliJ action (fails on VS Code / Cursor / browser hosts) |
| `Ide.Action(id)` | Semantic IDE action advertised in `Ide.Capabilities().result.actions` (e.g. terminal, problems, search) |
| `Ide.Projects()` | Known projects, live IDE sessions and configured application choices |
| `Ide.OpenProject({ projectId, applicationId, sessionId?, connectionId? })` | Open/Focus Project: focuses the exact existing session, otherwise opens the project in the configured installation |
| `Ide.StartApplication(applicationId)` | Starts an explicitly configured local application |

`Ide.Action`, `Ide.Projects`, `Ide.OpenProject` and `Ide.StartApplication` need µGulp™ 1.0.0 or later and use the host's IDE API license gate. Applications must be configured locally; requests cannot pass executable paths or shell commands. Open/Focus rejects stale or ambiguous sessions and never launches a duplicate after a failed focus attempt.

### IDE- und Projekt-API

Funktionsübersicht: Tabelle oben. Alle Aufrufe liefern ein Promise auf `{ ok, result?, code?, message? }` und werfen nie; ohne µGulp lautet das Ergebnis `{ ok: false, code: 'unsupported-host' }`. `Ide.Action`, `Ide.Projects`, `Ide.OpenProject` und `Ide.StartApplication` brauchen µGulp™ 1.0.0 oder neuer und nutzen die IDE-API-Lizenzprüfung des Hosts. Anwendungen werden ausschließlich lokal konfiguriert; Anfragen können keine Programmpfade oder Shell-Befehle übergeben. Open/Focus lehnt veraltete oder mehrdeutige Sitzungen ab und startet nach einem fehlgeschlagenen Fokusversuch kein Duplikat.
